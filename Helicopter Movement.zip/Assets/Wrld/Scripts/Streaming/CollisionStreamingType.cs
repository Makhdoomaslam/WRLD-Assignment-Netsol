﻿namespace Wrld.Streaming
{
    public enum CollisionStreamingType
    {
        NoCollision,
        SingleSidedCollision,
        DoubleSidedCollision
    }
}
