﻿using Wrld;
using UnityEngine;

namespace Wrld.MapCamera
{
    public class StreamingBehaviour : MonoBehaviour
    {
        //public void AttachStreamingCameras()
        //{
        //    var pluginRunner = GetComponent<ApiImplementation>();
        //    pluginRunner.AttachStreamingCameras();
        //}

        //public void DetachStreamingCameras()
        //{
        //    var pluginRunner = GetComponent<ApiImplementation>();
        //    pluginRunner.DetachStreamingCameras();
        //}

        //public void SyncStreamingCamera()
        //{
        //    var pluginRunner = GetComponent<ApiImplementation>();
        //    pluginRunner.SyncStreamingCamera();
        //}

        //public void SyncMainCamera()
        //{
        //    var pluginRunner = GetComponent<ApiImplementation>();
        //    pluginRunner.SyncMainCamera();
        //}
    } 
}
