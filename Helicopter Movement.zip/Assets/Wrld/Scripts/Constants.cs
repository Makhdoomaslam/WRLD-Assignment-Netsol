namespace Wrld
{
    public static class Constants
    {
        public const float RecommendedShadowDistance = 4000.0f;
    }
}
