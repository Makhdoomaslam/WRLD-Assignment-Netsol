﻿
namespace Wrld.Transport
{
    internal enum TransportGraphChangeReason
    {
        TransportGraphCellAdded,
        TransportGraphCellRemoved,
        TransportGraphCellUpdated // due to link/unlink
    };
}
