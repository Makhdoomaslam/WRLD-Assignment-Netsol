using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MostUsedInfo : MonoBehaviour
{
    public int bulletsCount = 0;
}
